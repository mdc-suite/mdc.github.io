# Installation guide

1. Prepare your SD Card

2. Extract the archive

3. Copy boot/ content in SD card first partition

4. Extract petalinux-image-minimal-zcu102-zynqmp.rootfs.tar.gz into SD card second partition

5. Copy ledController.bit.bin in /home/root/ of rootfs extracted in previous point

6. Connect and turn on ZCU102: https://mdc-suite.github.io/miscellaneous/yoctofpga
